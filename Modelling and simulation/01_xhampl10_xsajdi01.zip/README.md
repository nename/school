IMS
Program slouží jako projekt do předmětu modelování a simulace.
Simuluje linku vlaku Rumburk - Kolín.

Spuštení
./ims [-h -d {int} -t {int} -s {int} -v {float} -w {float}]

Argumenty:
-h : prints program help
-d {int} : number of days that simulation should run
-t {int} : number of trains
-s {int} : number of seats in train
-v {float} : maximal velocity of train in m/s
-w {float} : weight of train